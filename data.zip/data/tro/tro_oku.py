import os
import numpy as np
import pandas as pd
import datetime 
import time

def hour_rounder(t):
    # Rounds to nearest hour by adding a timedelta hour if minute >= 30
    return (t.replace(second=0, microsecond=0, minute=0, hour=t.hour)
               +datetime.timedelta(hours=t.minute//30))


flist = sorted([f for f in os.listdir("./") if f.endswith(".tro")])

merged_TRODRY = []
merged_TROWET = []
merged_DATE = []
merged_PWV = []
for fname in flist:
    filex = open(fname,"r")
    data = filex.readlines()
    filex.close()

    i = 0
    while i<(len(data)):
        try:
            if data[i].split()[1] == "____EPOCH___":
                i+=1
                break
        except:
            i += 1
        i+=1

    del data[:i]
    del data[-2:]
    print(data[0])
    TRODRY = []
    TROWET = []
    TRODATE = []
    for i in range(len(data)):
        TRODRY.append(float(data[i].split()[2]))
        TROWET.append(float(data[i].split()[3]))
        dd = datetime.timedelta(days = int(data[i].split()[1].split(":")[1])-1,seconds = int(data[i].split()[1].split(":")[2]))
        TRODATE.append(hour_rounder(datetime.datetime.strptime("20"+str(data[i].split()[1].split(":")[0]+"-01-01"),"%Y-%m-%d")+dd))
    merged_DATE.extend(TRODATE)
    merged_TROWET.extend(TROWET)
    merged_TRODRY.extend(TRODRY)

df = pd.DataFrame(list(zip(merged_DATE,merged_TRODRY,merged_TROWET)),columns=["date","trodry","trowet"])
df.to_excel("excel.xlsx")



df = pd.read_excel("excel.xlsx")

print(df)
df["time"] = pd.to_datetime(df["date"], format='%y/%m/%d %H:%M:%S')

df['time'] = df['time'].apply(lambda dt: datetime.datetime(dt.year, dt.month, dt.day, dt.hour,60*(dt.minute // 60)))
#df['date'] = df['date'].apply(lambda dt: datetime.datetime(dt.year, dt.month, dt.day, dt.hour,60*(dt.minute // 60)))

min_date = df.time.min()
max_date = df.time.max()
dates_range = pd.date_range(min_date, max_date, freq = '1H')
df.set_index('date', inplace=True)
df3=pd.DataFrame(dates_range).set_index(0)
df4 = df3.join(df)
print(df4)
df = df4.fillna(method="bfill")
df.to_excel("tro.xlsx")
